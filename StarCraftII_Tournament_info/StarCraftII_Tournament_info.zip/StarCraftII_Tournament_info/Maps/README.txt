Move into your StarCraft II folder.

to more Maps dowload here:

https://github.com/Blizzard/s2client-proto#map-packs